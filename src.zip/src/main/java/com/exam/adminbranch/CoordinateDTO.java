package com.exam.adminbranch;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

//가까운 지점을 찾기 위한 데이터 전송 DTO
public class CoordinateDTO {
	private Double latitude;
	private Double longitude;

}
