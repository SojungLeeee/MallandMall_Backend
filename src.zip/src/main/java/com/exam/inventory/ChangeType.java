package com.exam.inventory;

public enum ChangeType {
	IN, OUT
}